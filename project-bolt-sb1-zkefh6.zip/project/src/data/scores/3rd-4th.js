export const thirdFourthScores = [
  {
    date: "Nov 11, 2024",
    homeTeam: "Team Jackson",
    awayTeam: "Team Hinton",
    homeScore: 44,
    awayScore: 0
  },
  {
    date: "Nov 11, 2024",
    homeTeam: "Team Smelley",
    awayTeam: "Team Smith",
    homeScore: 6,
    awayScore: 18
  }
];