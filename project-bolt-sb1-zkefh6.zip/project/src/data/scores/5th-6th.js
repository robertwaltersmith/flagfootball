export const fifthSixthScores = [
  {
    date: "Nov 11, 2024",
    homeTeam: "Team 1",
    awayTeam: "Team 2",
    homeScore: 14,
    awayScore: 24
  },
  {
    date: "Nov 11, 2024",
    homeTeam: "Team 4",
    awayTeam: "Team 5",
    homeScore: 23,
    awayScore: 28
  }
];