export const firstSecondScores = [
  {
    date: "Nov 11, 2024",
    homeTeam: "Team Shetler",
    awayTeam: "Team Johnson",
    homeScore: 13,
    awayScore: 20
  }
];