export const thirdFourthGames = [
  {
    date: "Nov 11, 2024",
    time: "5:30 PM",
    homeTeam: "Team Jackson",
    awayTeam: "Team Hinton",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 11, 2024",
    time: "6:30 PM",
    homeTeam: "Team Smelley",
    awayTeam: "Team Smith",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 12, 2024",
    time: "5:30 PM",
    homeTeam: "Team Darsey",
    awayTeam: "Team Smith",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 12, 2024",
    time: "6:30 PM",
    homeTeam: "Team Jackson",
    awayTeam: "Team Kirkland",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 14, 2024",
    time: "5:30 PM",
    homeTeam: "Team Smelley",
    awayTeam: "Team Kirkland",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 14, 2024",
    time: "6:30 PM",
    homeTeam: "Team Darsey",
    awayTeam: "Team Hinton",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 18, 2024",
    time: "5:30 PM",
    homeTeam: "Team Kirkland",
    awayTeam: "Team Smith",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 18, 2024",
    time: "6:30 PM",
    homeTeam: "Team Jackson",
    awayTeam: "Team Smelley",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 19, 2024",
    time: "5:30 PM",
    homeTeam: "Team Smelley",
    awayTeam: "Team Hinton",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 19, 2024",
    time: "6:30 PM",
    homeTeam: "Team Kirkland",
    awayTeam: "Team Darsey",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 21, 2024",
    time: "5:30 PM",
    homeTeam: "Team Jackson",
    awayTeam: "Team Darsey",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Nov 21, 2024",
    time: "6:30 PM",
    homeTeam: "Team Smith",
    awayTeam: "Team Hinton",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 2, 2024",
    time: "5:30 PM",
    homeTeam: "Team Hinton",
    awayTeam: "Team Kirkland",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 2, 2024",
    time: "6:30 PM",
    homeTeam: "Team Smelley",
    awayTeam: "Team Darsey",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 3, 2024",
    time: "5:30 PM",
    homeTeam: "Team Jackson",
    awayTeam: "Team Smith",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 3, 2024",
    time: "6:30 PM",
    homeTeam: "Team Smelley",
    awayTeam: "Team Kirkland",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 5, 2024",
    time: "5:30 PM",
    homeTeam: "Team Jackson",
    awayTeam: "Team Darsey",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 5, 2024",
    time: "6:30 PM",
    homeTeam: "Team Hinton",
    awayTeam: "Team Smith",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 9, 2024",
    time: "5:30 PM",
    homeTeam: "Team Jackson",
    awayTeam: "Team Hinton",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 9, 2024",
    time: "6:30 PM",
    homeTeam: "Team Smith",
    awayTeam: "Team Darsey",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 10, 2024",
    time: "5:30 PM",
    homeTeam: "Team Darsey",
    awayTeam: "Team Kirkland",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 10, 2024",
    time: "6:30 PM",
    homeTeam: "Team Hinton",
    awayTeam: "Team Smelley",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 12, 2024",
    time: "5:30 PM",
    homeTeam: "Team Smelley",
    awayTeam: "Team Smith",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 12, 2024",
    time: "6:30 PM",
    homeTeam: "Team Jackson",
    awayTeam: "Team Kirkland",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 16, 2024",
    time: "5:30 PM",
    homeTeam: "Playoff Seed 3",
    awayTeam: "Playoff Seed 6",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 16, 2024",
    time: "6:30 PM",
    homeTeam: "Playoff Seed 4",
    awayTeam: "Playoff Seed 5",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 17, 2024",
    time: "5:30 PM",
    homeTeam: "Playoff Seed 2",
    awayTeam: "Winner (3/6)",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 17, 2024",
    time: "6:30 PM",
    homeTeam: "Playoff Seed 1",
    awayTeam: "Winner (4/5)",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  },
  {
    date: "Dec 19, 2024",
    time: "5:30 PM",
    homeTeam: "Championship Game",
    awayTeam: "TBD",
    location: "Demopolis Sports Plex Webb Field",
    ageGroup: "3rd-4th"
  }
]