export const firstSecondGames = [
  {
    date: "Nov 11, 2024",
    time: "5:30 PM",
    homeTeam: "Team Shetler",
    awayTeam: "Team Johnson",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Nov 12, 2024",
    time: "5:30 PM",
    homeTeam: "Team Shetler",
    awayTeam: "Team Miller",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Nov 14, 2024",
    time: "5:30 PM",
    homeTeam: "Team Johnson",
    awayTeam: "Team Miller",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Nov 18, 2024",
    time: "5:30 PM",
    homeTeam: "Team Johnson",
    awayTeam: "Team Miller",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Nov 19, 2024",
    time: "5:30 PM",
    homeTeam: "Team Shetler",
    awayTeam: "Team Johnson",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Nov 21, 2024",
    time: "5:30 PM",
    homeTeam: "Team Shetler",
    awayTeam: "Team Miller",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Dec 2, 2024",
    time: "5:30 PM",
    homeTeam: "Team Johnson",
    awayTeam: "Team Miller",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Dec 3, 2024",
    time: "5:30 PM",
    homeTeam: "Team Shetler",
    awayTeam: "Team Johnson",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Dec 5, 2024",
    time: "5:30 PM",
    homeTeam: "Team Shetler",
    awayTeam: "Team Miller",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Dec 9, 2024",
    time: "5:30 PM",
    homeTeam: "Team Shetler",
    awayTeam: "Team Johnson",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Dec 10, 2024",
    time: "5:30 PM",
    homeTeam: "Team Johnson",
    awayTeam: "Team Miller",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Dec 12, 2024",
    time: "5:30 PM",
    homeTeam: "Team Shetler",
    awayTeam: "Team Miller",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Dec 17, 2024",
    time: "5:30 PM",
    homeTeam: "Playoff Seed 3",
    awayTeam: "Playoff Seed 2",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  },
  {
    date: "Dec 19, 2024",
    time: "5:30 PM",
    homeTeam: "Winner (2/3)",
    awayTeam: "Playoff Seed 1",
    location: "Demopolis Sports Plex Field 2",
    ageGroup: "1st-2nd"
  }
];